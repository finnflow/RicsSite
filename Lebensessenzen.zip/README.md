
  # Lebensessenz

  This is a code bundle for Lebensessenz. The original project is available at https://www.figma.com/design/vkIVxKzvjzvkxNKdyhcnDz/Lebensessenz.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  